# Ex2 - SuDoKu grabber: grid detection with Hough lines (Python port of the AI Shack C++ code)
# Input: sudoku.jpg <- https://aishack.in/static/img/tut/sudoku-original.jpg
import cv2
import numpy as np

STUDENT_ID = "52300009"


def stamp(img):
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.putText(img, STUDENT_ID, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(img, STUDENT_ID, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2, cv2.LINE_AA)
    return img


def draw_line(line, img, color=255):
    """Draw a (rho, theta) line across the whole image (port of drawLine in the article)."""
    rho, theta = line
    h, w = img.shape[:2]
    if theta != 0:
        m = -1 / np.tan(theta)
        c = rho / np.sin(theta)
        cv2.line(img, (0, int(c)), (w, int(m * w + c)), color, 1)
    else:
        cv2.line(img, (int(rho), 0), (int(rho), h), color, 1)


sudoku = cv2.imread("sudoku.jpg", 0)                     # grayscale

# --- Preprocessing ---
sudoku = cv2.GaussianBlur(sudoku, (11, 11), 0)
outer = cv2.adaptiveThreshold(sudoku, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 5, 2)
outer = cv2.bitwise_not(outer)                           # borders become white
kernel = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], np.uint8)   # plus-shaped element
outer = cv2.dilate(outer, kernel)                        # close small cracks
cv2.imwrite("image_02_01.png", stamp(outer.copy()))      # inverted + dilated

# --- Finding the biggest blob (flood fill) ---
max_area, max_pt = -1, (0, 0)
h, w = outer.shape
for y in range(h):
    for x in range(w):
        if outer[y, x] >= 128:
            area, _, _, _ = cv2.floodFill(outer, None, (x, y), 64)
            if area > max_area:
                max_area, max_pt = area, (x, y)

cv2.floodFill(outer, None, max_pt, 255)                  # biggest blob -> white
for y in range(h):                                       # all other blobs -> black
    for x in range(w):
        if outer[y, x] == 64:
            cv2.floodFill(outer, None, (x, y), 0)

outer = cv2.erode(outer, kernel)                         # undo dilation
cv2.imwrite("image_02_02.png", stamp(outer.copy()))      # biggest blob only

# --- Detecting lines ---
lines = cv2.HoughLines(outer, 1, np.pi / 180, 200)
result = outer.copy()
if lines is not None:
    print("lines found:", len(lines))
    for l in np.asarray(lines).reshape(-1, 2):
        draw_line(l, result, 128)
cv2.imwrite("image_02_03.png", stamp(result))            # Hough lines
