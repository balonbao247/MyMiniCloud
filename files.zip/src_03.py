# Ex3 - Detect and read barcodes with OpenCV (cv2.barcode.BarcodeDetector)
import cv2
import numpy as np

STUDENT_ID = "52300009"

img = cv2.imread("barcode.jpg")
H, W = img.shape[:2]
bd = cv2.barcode.BarcodeDetector()


def ean13_valid(code):
    """Checksum test so wrong/partial reads are rejected."""
    if len(code) != 13 or not code.isdigit():
        return False
    d = [int(c) for c in code]
    s = sum(d[i] * (3 if i % 2 else 1) for i in range(12))
    return (10 - s % 10) % 10 == d[12]


def preprocess(gray, mode):
    if mode == "sharp":    # unsharp mask
        return cv2.addWeighted(gray, 1.8, cv2.GaussianBlur(gray, (0, 0), 3), -0.8, 0)
    if mode == "clahe":
        return cv2.createCLAHE(2.0, (8, 8)).apply(gray)
    return gray


found = {}  # code -> (type, 4x2 points in original image coordinates)

# Regions: whole image first, then the four quadrants (barcodes are small in a big image)
rois = [(0, 0, W, H),
        (0, 0, W // 2 + 20, H // 2), (W // 2 - 20, 0, W, H // 2),
        (0, H // 2 - 20, W // 2 + 20, H), (W // 2 - 20, H // 2 - 20, W, H)]

for (x0, y0, x1, y1) in rois:
    roi = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2GRAY)
    rh, rw = roi.shape
    for scale in (1, 2, 2.5, 3):
        for rot in (0, 180):                       # upside-down book is in the image
            for mode in ("gray", "sharp", "clahe"):
                g = cv2.resize(roi, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
                if rot:
                    g = cv2.rotate(g, cv2.ROTATE_180)
                g = preprocess(g, mode)
                ok, infos, types, pts = bd.detectAndDecodeWithType(g)
                if not ok or pts is None:
                    continue
                for s, t, p in zip(infos, types, pts):
                    if s in found or not ean13_valid(s):
                        continue
                    p = np.array(p, dtype=np.float32)
                    gh, gw = g.shape
                    if rot:                       # undo rotation
                        p = np.stack([gw - 1 - p[:, 0], gh - 1 - p[:, 1]], axis=1)
                    p = p / scale + np.array([x0, y0], dtype=np.float32)   # undo scale + crop
                    found[s] = (t, p)

print("Detected barcodes:", len(found))
out = img.copy()
for s, (t, p) in found.items():
    print(f"  {s}  type={t}")
    cv2.polylines(out, [p.astype(int)], True, (0, 255, 0), 3)
    x, y = p.min(axis=0).astype(int)
    cv2.putText(out, s, (int(max(x, 0)), int(max(y - 6, 14))),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 255), 2, cv2.LINE_AA)

# Student ID on the output image
cv2.putText(out, STUDENT_ID, (10, H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 4, cv2.LINE_AA)
cv2.putText(out, STUDENT_ID, (10, H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 1, cv2.LINE_AA)
cv2.imwrite("image_03_01.png", out)
