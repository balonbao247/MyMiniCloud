# Ex1 - Edge detection (Sobel, Canny), Hough line (standard + probabilistic), Hough circle
# Inputs (download first):
#   sudoku.jpg  <- https://aishack.in/static/img/tut/sudoku-original.jpg
#   circles.png <- http://amroamroamro.github.io/mexopencv/opencv/hough_circles_demo_01.png
import cv2
import numpy as np

STUDENT_ID = "52300009"


def stamp(img):
    """Add Student ID text to an output image (converts gray -> BGR)."""
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.putText(img, STUDENT_ID, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(img, STUDENT_ID, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2, cv2.LINE_AA)
    return img


def save(name, img):
    cv2.imwrite(name, stamp(img.copy()))


# ---------- 1. Edge detection ----------
img = cv2.imread("sudoku.jpg")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
blur = cv2.GaussianBlur(gray, (3, 3), 0)

sx = cv2.Sobel(blur, cv2.CV_64F, 1, 0, ksize=5)
sy = cv2.Sobel(blur, cv2.CV_64F, 0, 1, ksize=5)
sxy = cv2.Sobel(blur, cv2.CV_64F, 1, 1, ksize=5)
save("image_01_01.png", cv2.convertScaleAbs(sxy))      # Sobel (XY)
canny = cv2.Canny(blur, 100, 200)
save("image_01_02.png", canny)                           # Canny

# ---------- 2. Hough line transform ----------
edges = cv2.Canny(gray, 50, 150, apertureSize=3)

std = img.copy()                                         # standard
lines = cv2.HoughLines(edges, 1, np.pi / 180, 200)
if lines is not None:
    for rho, theta in np.asarray(lines).reshape(-1, 2):
        a, b = np.cos(theta), np.sin(theta)
        x0, y0 = a * rho, b * rho
        p1 = (int(x0 + 1000 * (-b)), int(y0 + 1000 * a))
        p2 = (int(x0 - 1000 * (-b)), int(y0 - 1000 * a))
        cv2.line(std, p1, p2, (0, 0, 255), 2, cv2.LINE_AA)
save("image_01_03.png", std)                             # HoughLines

prob = img.copy()                                        # probabilistic
linesP = cv2.HoughLinesP(edges, 1, np.pi / 180, 50, minLineLength=50, maxLineGap=10)
if linesP is not None:
    for x1, y1, x2, y2 in np.asarray(linesP).reshape(-1, 4):
        cv2.line(prob, (x1, y1), (x2, y2), (0, 0, 255), 2, cv2.LINE_AA)
save("image_01_04.png", prob)                            # HoughLinesP

# ---------- 3. Hough circle transform ----------
cimg = cv2.imread("circles.png")
cgray = cv2.medianBlur(cv2.cvtColor(cimg, cv2.COLOR_BGR2GRAY), 5)
circles = cv2.HoughCircles(cgray, cv2.HOUGH_GRADIENT, 1, cgray.shape[0] / 8,
                           param1=100, param2=30, minRadius=0, maxRadius=0)
if circles is not None:
    for x, y, r in np.round(np.asarray(circles).reshape(-1, 3)).astype(int):
        cv2.circle(cimg, (x, y), r, (0, 255, 0), 2)      # outline
        cv2.circle(cimg, (x, y), 2, (0, 0, 255), 3)      # center
save("image_01_05.png", cimg)                            # HoughCircles
